// JavaScript source code
let gameBoard = [];
let activeSquare;
let phase = 1;

// Create an array of empty squares
for (let i = 0; i < 15; i++)
{
    gameBoard.push([]);
    for (let j = 0; i < 15; j++) {
        let square = "empty";
        gameBoard[i].push(square);
    }
}

// Phase 1: Placing your pieces
if (phase == 1)
{
    // Close off all squares besides starting area

}

// If a piece is placed, update the square in the array and then update HTML board
function PiecePlaced(piece, location)
{
    // Update the array with that piece's name in that location

    // Update the HTML gameboard
}
